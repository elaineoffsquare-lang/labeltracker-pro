
import { useState, useEffect, useCallback } from 'react';
import { ShipmentRepository } from '../data/shipment/ShipmentRepository';
import { ShipmentEntity, ShipmentStatus } from '../data/entity/ShipmentEntity';

export const useShipmentViewModel = () => {
  const repo = new ShipmentRepository();
  const [shipments, setShipments] = useState<ShipmentEntity[]>([]);

  const refresh = useCallback(() => {
    setShipments(repo.getAll());
  }, []);

  useEffect(() => {
    refresh();
    window.addEventListener('db_updated', refresh);
    return () => window.removeEventListener('db_updated', refresh);
  }, []);

  const updateShipmentStatus = (id: string, status: ShipmentStatus) => {
    repo.updateStatus(id, status);
  };

  const addShipment = (s: ShipmentEntity) => {
    repo.insert(s);
  };

  return { shipments, updateShipmentStatus, addShipment };
};
