
import { useState, useEffect, useCallback } from 'react';
import { ProductRepository } from '../data/product/ProductRepository';
import { OrderRepository } from '../data/order/OrderRepository';
import { ShipmentRepository } from '../data/shipment/ShipmentRepository';
import { GoogleGenAI } from "@google/genai";
import { PaymentStatus } from '../data/entity/OrderEntity';

export const useDashboardViewModel = () => {
  const pRepo = new ProductRepository();
  const oRepo = new OrderRepository();
  const sRepo = new ShipmentRepository();

  const [insight, setInsight] = useState("Analyzing business data...");
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalRevenue: 0,
    accountsReceivable: 0, // Total of orders marked as CREDIT
    lowStockCount: 0,
    activeShipments: 0
  });

  const refresh = useCallback(() => {
    const products = pRepo.getAll();
    const orders = oRepo.getAll();
    const shipments = sRepo.getAll();

    setStats({
      totalOrders: orders.length,
      totalRevenue: orders.reduce((sum, o) => sum + o.totalAmount, 0),
      accountsReceivable: orders
        .filter(o => o.paymentStatus === PaymentStatus.CREDIT)
        .reduce((sum, o) => sum + o.totalAmount, 0),
      lowStockCount: products.filter(p => p.stockQuantity <= p.minStockAlertLevel).length,
      activeShipments: shipments.filter(s => s.status !== 'DELIVERED').length
    });
  }, []);

  const fetchAIInsights = async () => {
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Analyze inventory: ${JSON.stringify(pRepo.getAll())}. Analyze sales: ${JSON.stringify(oRepo.getAll())}. Give one high-impact business advice (max 2 sentences). Include mention of cash flow if there's high accounts receivable.`;
    
    try {
      const res = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      setInsight(res.text || "Keep monitoring your SKU performance.");
    } catch (e) {
      setInsight("Enable Gemini API for strategic insights.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    fetchAIInsights();
    window.addEventListener('db_updated', refresh);
    return () => window.removeEventListener('db_updated', refresh);
  }, []);

  return { stats, insight, loading, refreshInsights: fetchAIInsights };
};
