
import { useState, useEffect, useCallback } from 'react';
import { ProductRepository } from '../data/product/ProductRepository';
import { ProductEntity } from '../data/entity/ProductEntity';

export const useProductViewModel = () => {
  const repo = new ProductRepository();
  const [products, setProducts] = useState<ProductEntity[]>([]);

  const refresh = useCallback(() => {
    setProducts(repo.getAll());
  }, []);

  useEffect(() => {
    refresh();
    window.addEventListener('db_updated', refresh);
    return () => window.removeEventListener('db_updated', refresh);
  }, []);

  const addProduct = (p: ProductEntity) => repo.insert(p);
  const updateProduct = (p: ProductEntity) => repo.update(p);
  const removeProduct = (id: string) => repo.delete(id);

  return { products, addProduct, updateProduct, removeProduct };
};
