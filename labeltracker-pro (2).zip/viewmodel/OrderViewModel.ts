
import { useState, useEffect, useCallback } from 'react';
import { OrderRepository } from '../data/order/OrderRepository';
import { OrderEntity } from '../data/entity/OrderEntity';

export const useOrderViewModel = () => {
  const repo = new OrderRepository();
  const [orders, setOrders] = useState<OrderEntity[]>([]);

  const refresh = useCallback(() => {
    setOrders(repo.getAll());
  }, []);

  useEffect(() => {
    refresh();
    window.addEventListener('db_updated', refresh);
    return () => window.removeEventListener('db_updated', refresh);
  }, []);

  const addOrder = (o: OrderEntity) => repo.insert(o);
  const cancelOrder = (id: string) => repo.delete(id);

  return { orders, addOrder, cancelOrder };
};
