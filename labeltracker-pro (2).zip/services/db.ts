
import { Product, Order, Shipment, User, UserRole } from '../types';

const STORAGE_KEY = 'labeltracker_pro_v3_db';

interface DatabaseSchema {
  version: string;
  lastSync: number;
  products: Product[];
  orders: Order[];
  shipments: Shipment[];
  users: User[];
}

const INITIAL_STATE: DatabaseSchema = {
  version: '3.0.0',
  lastSync: Date.now(),
  products: [
    { id: '1', productName: 'Premium Matte Vinyl', labelName: 'SKU-001', unitPrice: 20.00, stockQuantity: 100, minStockAlertLevel: 10, size: '10cm x 15cm', pcsPerRoll: 500 },
    { id: '2', productName: 'Glossy Finish Wrap', labelName: 'SKU-002', unitPrice: 25.00, stockQuantity: 5, minStockAlertLevel: 10, size: 'A4', pcsPerRoll: 100 }
  ],
  orders: [],
  shipments: [],
  users: [
    { id: 'u1', username: 'admin', displayName: 'Admin User', role: UserRole.ADMIN }
  ]
};

/**
 * Advanced Database Service
 * In a production environment, 'save' would push to a REST API (Firebase/Supabase)
 * and 'get' would pull from the cloud.
 */
export const db = {
  get: (): DatabaseSchema => {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return INITIAL_STATE;
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error("Corruption detected in local storage. Resetting to initial state.");
      return INITIAL_STATE;
    }
  },

  save: (data: DatabaseSchema) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      ...data,
      lastSync: Date.now()
    }));
    // Trigger a custom event so the UI knows to refresh
    window.dispatchEvent(new Event('db_updated'));
  },

  /**
   * Simulated Cloud Syncing
   */
  sync: async (): Promise<boolean> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log("Database synced with simulated cloud storage.");
        resolve(true);
      }, 1500);
    });
  },

  reset: () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_STATE));
    window.location.reload();
  }
};
