
import React, { useState } from 'react';
import { Order, Product } from '../../types';

interface OrderListProps {
  orders: Order[];
  products: Product[];
  onAdd: (o: Order) => void;
  onDelete: (id: string) => void;
}

const OrderList: React.FC<OrderListProps> = ({ orders, products, onAdd, onDelete }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    customerName: '',
    productId: '',
    quantity: 1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find(p => p.id === formData.productId);
    if (!product) return;

    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9),
      orderNumber: `ORD-${Date.now().toString().slice(-4)}`,
      customerName: formData.customerName,
      productId: product.id,
      productName: product.productName,
      quantity: formData.quantity,
      sellingPrice: product.unitPrice,
      totalAmount: product.unitPrice * formData.quantity,
      orderDate: Date.now()
    };
    
    onAdd(newOrder);
    setIsAdding(false);
    setFormData({ customerName: '', productId: '', quantity: 1 });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-gray-800">Sales Orders</h3>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold"
        >
          + New Order
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-xl border-2 border-green-100 shadow-md">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Customer</label>
              <input 
                type="text" required
                value={formData.customerName}
                onChange={e => setFormData({...formData, customerName: e.target.value})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-green-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Product</label>
              <select 
                required
                value={formData.productId}
                onChange={e => setFormData({...formData, productId: e.target.value})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-green-500 outline-none"
              >
                <option value="">Select a product...</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.productName} (${p.unitPrice})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Quantity</label>
              <input 
                type="number" required min="1"
                value={formData.quantity}
                onChange={e => setFormData({...formData, quantity: Number(e.target.value)})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-green-500 outline-none"
              />
            </div>
            <div className="md:col-span-3 flex justify-end space-x-3 mt-2">
              <button 
                type="button" 
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="bg-green-600 text-white px-6 py-2 rounded font-bold hover:bg-green-700"
              >
                Create Order
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">Order #</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">Customer</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">Item</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-center">Qty</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-right">Total</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {orders.map(order => (
              <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 font-mono font-bold text-blue-600 text-sm">{order.orderNumber}</td>
                <td className="px-6 py-4 text-gray-900 font-medium">{order.customerName}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{order.productName}</td>
                <td className="px-6 py-4 text-center text-sm font-semibold">{order.quantity}</td>
                <td className="px-6 py-4 text-right text-sm font-bold text-gray-900">${order.totalAmount.toFixed(2)}</td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onDelete(order.id)}
                    className="text-red-400 hover:text-red-600 p-1"
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrderList;
