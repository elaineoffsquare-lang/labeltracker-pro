
import React, { useState } from 'react';
import { Product } from '../../types';

interface ProductListProps {
  products: Product[];
  onAdd: (p: Product) => void;
  onUpdate: (p: Product) => void;
  onDelete: (id: string) => void;
}

const ProductList: React.FC<ProductListProps> = ({ products, onAdd, onUpdate, onDelete }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState<Partial<Product>>({
    productName: '',
    labelName: '',
    unitPrice: 0,
    stockQuantity: 0,
    minStockAlertLevel: 10
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newProduct: Product = {
      id: Math.random().toString(36).substr(2, 9),
      productName: formData.productName || 'New Product',
      labelName: formData.labelName || 'SKU-000',
      unitPrice: Number(formData.unitPrice) || 0,
      stockQuantity: Number(formData.stockQuantity) || 0,
      minStockAlertLevel: Number(formData.minStockAlertLevel) || 10,
    };
    onAdd(newProduct);
    setIsAdding(false);
    setFormData({ productName: '', labelName: '', unitPrice: 0, stockQuantity: 0, minStockAlertLevel: 10 });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-gray-800">Master Inventory</h3>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
        >
          + Add Product
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-xl border-2 border-blue-100 shadow-md">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Product Name</label>
              <input 
                type="text" required
                value={formData.productName}
                onChange={e => setFormData({...formData, productName: e.target.value})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">SKU / Label Name</label>
              <input 
                type="text" required
                value={formData.labelName}
                onChange={e => setFormData({...formData, labelName: e.target.value})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Unit Price ($)</label>
              <input 
                type="number" required
                value={formData.unitPrice}
                onChange={e => setFormData({...formData, unitPrice: Number(e.target.value)})}
                className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Stock Qty</label>
                <input 
                  type="number" required
                  value={formData.stockQuantity}
                  onChange={e => setFormData({...formData, stockQuantity: Number(e.target.value)})}
                  className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Min Level</label>
                <input 
                  type="number" required
                  value={formData.minStockAlertLevel}
                  onChange={e => setFormData({...formData, minStockAlertLevel: Number(e.target.value)})}
                  className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>
            <div className="md:col-span-2 flex justify-end space-x-3 mt-2">
              <button 
                type="button" 
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700"
              >
                Save Product
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">Product</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">SKU</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-center">In Stock</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-right">Price</th>
              <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {products.map(product => {
              const isLow = product.stockQuantity <= product.minStockAlertLevel;
              return (
                <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{product.productName}</td>
                  <td className="px-6 py-4 text-sm text-gray-500 font-mono">{product.labelName}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                      isLow ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                    }`}>
                      {product.stockQuantity}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-bold text-gray-700">${product.unitPrice.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => onDelete(product.id)}
                      className="text-red-400 hover:text-red-600 p-1"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProductList;
