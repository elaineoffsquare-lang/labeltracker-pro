
import React from 'react';
import { useDashboardViewModel } from '../../viewmodel/DashboardViewModel';
import { useProductViewModel } from '../../viewmodel/ProductViewModel';

const DashboardScreen: React.FC = () => {
  const { stats, insight, loading } = useDashboardViewModel();
  const { products } = useProductViewModel();

  // Calculate total individual pieces across all rolls in stock
  const totalEstimatedPieces = products.reduce((acc, p) => acc + (p.stockQuantity * (p.pcsPerRoll || 0)), 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
        <StatCard title="Total Sales" value={`$${stats.totalRevenue.toFixed(2)}`} icon="💰" color="text-green-600" />
        <StatCard title="Total Credit (A/R)" value={`$${stats.accountsReceivable.toFixed(2)}`} icon="💳" color="text-orange-500" />
        <StatCard title="Est. Total Pcs" value={totalEstimatedPieces.toLocaleString()} icon="🔢" color="text-blue-500" />
        <StatCard title="Low Stock SKU" value={stats.lowStockCount} icon="⚠️" color="text-red-600" />
        <StatCard title="Active Logistics" value={stats.activeShipments} icon="🚚" color="text-indigo-600" />
      </div>

      <div className="bg-slate-900 text-white rounded-3xl p-10 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-10 opacity-10 text-9xl transform group-hover:scale-110 transition-transform duration-700">✨</div>
        <div className="relative z-10 space-y-4">
          <div className="flex items-center space-x-2">
            <span className="bg-blue-500 text-[10px] font-bold px-2 py-0.5 rounded tracking-widest uppercase">AI Strategy</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight">LabelTracker Insights</h2>
          {loading ? (
            <div className="animate-pulse space-y-2">
              <div className="h-4 bg-slate-700 rounded w-3/4"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2"></div>
            </div>
          ) : (
            <p className="text-xl text-slate-300 leading-relaxed italic max-w-2xl">
              "{insight}"
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, color }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-2">
      <span className="text-2xl">{icon}</span>
      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Real-time</span>
    </div>
    <p className="text-sm font-medium text-gray-500 uppercase">{title}</p>
    <p className={`text-2xl font-bold ${color} tracking-tight mt-1`}>{value}</p>
  </div>
);

export default DashboardScreen;
