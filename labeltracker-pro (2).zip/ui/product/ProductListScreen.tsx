
import React, { useState, useMemo } from 'react';
import { useProductViewModel } from '../../viewmodel/ProductViewModel';
import { ProductEntity } from '../../data/entity/ProductEntity';

const ProductListScreen: React.FC = () => {
  const { products, addProduct, updateProduct, removeProduct } = useProductViewModel();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({ 
    name: '', 
    price: '0.00', 
    stock: '0', 
    alert: '5',
    size: '',
    pcsPerRoll: '',
    invoiceNumber: '',
    invoiceDate: new Date().toISOString().split('T')[0]
  });

  const uniqueProductNames = useMemo(() => {
    const names = products.map(p => p.productName);
    return Array.from(new Set(names)).sort();
  }, [products]);

  const generateSKU = (name: string, size: string) => {
    const random = Math.floor(100 + Math.random() * 900);
    return `SKU-${random}`; 
  };

  const handleNameChange = (name: string) => {
    setFormData(prev => {
      const newData = { ...prev, name };
      
      // Auto-fill logic: only trigger if we are NOT editing an existing specific product
      if (!editingId) {
        const match = products.find(p => p.productName.toLowerCase() === name.toLowerCase());
        if (match) {
          return {
            ...newData,
            size: match.size || prev.size,
            pcsPerRoll: match.pcsPerRoll?.toString() || prev.pcsPerRoll,
            price: match.unitPrice.toString() || prev.price,
            alert: match.minStockAlertLevel.toString() || prev.alert
          };
        }
      }
      
      return newData;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const existing = editingId ? products.find(p => p.id === editingId) : null;
    
    const productData: ProductEntity = {
      id: editingId || Date.now().toString(),
      productName: formData.name,
      labelName: existing?.labelName || generateSKU(formData.name, formData.size),
      unitPrice: parseFloat(formData.price) || 0,
      stockQuantity: parseInt(formData.stock) || 0,
      minStockAlertLevel: parseInt(formData.alert) || 0,
      size: formData.size || '-',
      pcsPerRoll: parseInt(formData.pcsPerRoll) || 0,
      lastInvoiceNumber: formData.invoiceNumber || undefined,
      lastInvoiceDate: formData.invoiceNumber ? new Date(formData.invoiceDate).getTime() : undefined
    };

    if (editingId) {
      updateProduct(productData);
    } else {
      addProduct(productData);
    }

    resetForm();
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({ 
      name: '', 
      price: '0.00', 
      stock: '0', 
      alert: '5',
      size: '',
      pcsPerRoll: '',
      invoiceNumber: '',
      invoiceDate: new Date().toISOString().split('T')[0]
    });
  };

  const handleEdit = (p: ProductEntity) => {
    setEditingId(p.id);
    setFormData({
      name: p.productName,
      price: p.unitPrice.toString(),
      stock: p.stockQuantity.toString(),
      alert: p.minStockAlertLevel.toString(),
      size: p.size || '',
      pcsPerRoll: p.pcsPerRoll?.toString() || '',
      invoiceNumber: p.lastInvoiceNumber || '',
      invoiceDate: p.lastInvoiceDate 
        ? new Date(p.lastInvoiceDate).toISOString().split('T')[0] 
        : new Date().toISOString().split('T')[0]
    });
    setShowForm(true);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-[#1E293B] tracking-tight">Product Catalog</h2>
          <p className="text-[11px] text-slate-400 font-black uppercase tracking-[0.25em] mt-1.5">Manage sizes, stock, and roll specs</p>
        </div>
        <button 
          onClick={() => { if(showForm) resetForm(); else setShowForm(true); }}
          className="bg-blue-600 text-white px-8 py-3 rounded-2xl font-black text-sm hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 active:scale-95"
        >
          {showForm ? 'Close' : '+ New Product'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-12 rounded-[40px] shadow-2xl shadow-slate-200/50 border border-slate-100 animate-in slide-in-from-top-4 duration-500">
          <form onSubmit={handleSubmit} className="space-y-10">
            {/* Row 1 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Product Description</label>
                <input 
                  required 
                  list="existing-names"
                  value={formData.name} 
                  onChange={e => handleNameChange(e.target.value)} 
                  className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 placeholder:text-slate-300 transition-all" 
                  placeholder="e.g. Premium Matte Vinyl" 
                />
                <datalist id="existing-names">
                  {uniqueProductNames.map(name => <option key={name} value={name} />)}
                </datalist>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Size / Specification</label>
                <input required value={formData.size} onChange={e => setFormData({...formData, size: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 placeholder:text-slate-300 transition-all" placeholder="e.g. 10cm x 15cm" />
              </div>
            </div>

            {/* Row 2 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <div>
                <label className="text-[10px] font-black text-blue-600 uppercase block mb-3 tracking-widest">Pieces per Roll</label>
                <input type="number" value={formData.pcsPerRoll} onChange={e => setFormData({...formData, pcsPerRoll: e.target.value})} className="w-full bg-blue-50/30 border-blue-50 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-blue-700 placeholder:text-blue-200 transition-all" placeholder="e.g. 500" />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Unit Price ($)</label>
                <input type="number" step="any" min="0" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 placeholder:text-slate-300 transition-all" placeholder="0.00" />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Current Stock (Rolls)</label>
                <input type="number" min="0" value={formData.stock} onChange={e => setFormData({...formData, stock: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 placeholder:text-slate-300 transition-all" placeholder="0" />
              </div>
            </div>

            {/* Row 3 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Low Stock Alert Level</label>
                <input type="number" min="0" value={formData.alert} onChange={e => setFormData({...formData, alert: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 transition-all" placeholder="5" />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Last Invoice Number</label>
                <input value={formData.invoiceNumber} onChange={e => setFormData({...formData, invoiceNumber: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 placeholder:text-slate-300 transition-all" placeholder="e.g. INV-9921" />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Purchase Date</label>
                <input type="date" value={formData.invoiceDate} onChange={e => setFormData({...formData, invoiceDate: e.target.value})} className="w-full bg-[#F8FAFC] border-slate-100 border p-4 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none font-bold text-slate-700 transition-all" />
              </div>
            </div>

            <div className="flex justify-end items-center space-x-6 pt-4 border-t border-slate-50">
               <button type="button" onClick={resetForm} className="px-10 py-4 bg-slate-50 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-100 transition-all">Cancel</button>
               <button type="submit" className="px-16 py-4 bg-[#0F172A] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-slate-300 hover:bg-black transition-all active:scale-95">
                {editingId ? 'Update Entry' : 'Create Entry'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Table Section */}
      <div className="bg-white rounded-[40px] shadow-sm border border-slate-50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#F8FAFC] border-b border-slate-100">
              <tr>
                <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Product & Size</th>
                <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Qty / Roll</th>
                <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Price Record</th>
                <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Invoice Ref</th>
                <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">In Stock</th>
                <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {products.map(p => {
                const low = p.stockQuantity <= p.minStockAlertLevel;
                return (
                  <tr key={p.id} className="hover:bg-slate-50/50 transition-all duration-300 group">
                    <td className="px-10 py-8">
                      <div className="font-black text-[#1E293B] text-lg tracking-tight mb-2">{p.productName}</div>
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg bg-blue-50 text-[10px] font-black text-blue-600 uppercase tracking-tighter border border-blue-100/50">
                        {p.size}
                      </span>
                    </td>
                    <td className="px-6 py-8 text-center">
                      <div className="text-sm font-black text-slate-700 mb-0.5">{p.pcsPerRoll}</div>
                      <div className="text-[10px] text-slate-300 font-black uppercase tracking-widest">PCS</div>
                    </td>
                    <td className="px-6 py-8">
                      <div className="text-base font-black text-slate-900 mb-1">${p.unitPrice}</div>
                      <div className="font-mono text-[10px] text-slate-300 font-bold uppercase tracking-widest">{p.labelName}</div>
                    </td>
                    <td className="px-6 py-8">
                      {p.lastInvoiceNumber ? (
                        <div className="text-[11px] text-slate-400 font-bold italic">Ref: {p.lastInvoiceNumber}</div>
                      ) : (
                        <span className="text-xs text-slate-200 italic font-medium">No record</span>
                      )}
                    </td>
                    <td className="px-6 py-8 text-center">
                      <div className={`inline-flex items-center justify-center px-4 py-1.5 rounded-full text-[11px] font-black tracking-tight border ${
                        low 
                        ? 'bg-red-50 text-red-500 border-red-100 shadow-sm shadow-red-50' 
                        : 'bg-emerald-50 text-emerald-500 border-emerald-100 shadow-sm shadow-emerald-50'
                      }`}>
                        {p.stockQuantity}
                        {low && <span className="ml-1.5">⚠️</span>}
                      </div>
                      <div className="text-[9px] text-slate-300 font-black uppercase mt-1.5 tracking-widest">ROLLS</div>
                    </td>
                    <td className="px-10 py-8 text-right">
                      <div className="flex justify-end space-x-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
                        <button onClick={() => handleEdit(p)} className="w-10 h-10 bg-white border border-slate-100 text-blue-500 rounded-xl flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                          ✏️
                        </button>
                        <button onClick={() => removeProduct(p.id)} className="w-10 h-10 bg-white border border-slate-100 text-red-400 rounded-xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all shadow-sm">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductListScreen;
