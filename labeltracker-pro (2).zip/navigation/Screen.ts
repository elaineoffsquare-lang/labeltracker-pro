
export enum Screen {
  Dashboard = 'DASHBOARD',
  Products = 'PRODUCTS',
  Orders = 'ORDERS',
  Shipments = 'SHIPMENTS',
  Users = 'USERS'
}
