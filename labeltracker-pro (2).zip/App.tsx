
import React, { useState, useEffect, useRef } from 'react';
import { Screen } from './navigation/Screen';
import Layout from './components/Layout';
import DashboardScreen from './ui/dashboard/DashboardScreen';
import ProductListScreen from './ui/product/ProductListScreen';
import OrderListScreen from './ui/order/OrderListScreen';
import ShipmentListScreen from './ui/shipment/ShipmentListScreen';
import { db } from './services/db';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Dashboard);
  const [isSyncing, setIsSyncing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const currentUser = db.get().users[0];

  // Simulated Sync on load
  useEffect(() => {
    const performInitialSync = async () => {
      setIsSyncing(true);
      await new Promise(r => setTimeout(r, 1000)); // Mimic network delay
      setIsSyncing(false);
    };
    performInitialSync();
  }, []);

  const handleExport = () => {
    const data = db.get();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `labeltracker_pro_export_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.products && json.orders) {
          db.save(json);
          alert('Database restored successfully.');
          window.location.reload();
        }
      } catch (err) {
        alert('Error: Invalid backup file.');
      }
    };
    reader.readAsText(file);
  };

  const renderContent = () => {
    return (
      <div className="page-transition">
        {(() => {
          switch (currentScreen) {
            case Screen.Dashboard: return <DashboardScreen />;
            case Screen.Products: return <ProductListScreen />;
            case Screen.Orders: return <OrderListScreen />;
            case Screen.Shipments: return <ShipmentListScreen />;
            case Screen.Users:
              return (
                <div className="p-10 space-y-10">
                  <div className="bg-white rounded-[40px] p-10 border border-slate-100 shadow-sm">
                    <h2 className="text-2xl font-black text-slate-800 tracking-tight mb-8">System Infrastructure</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="p-8 bg-blue-50/50 rounded-3xl border border-blue-100">
                          <h3 className="font-black text-blue-900 uppercase text-xs tracking-widest mb-4">Cloud Synchronization</h3>
                          <p className="text-sm text-blue-700 font-medium mb-6 leading-relaxed">Your data is currently stored in the secure browser vault. For multi-device support, connect a backend service.</p>
                          <div className="flex gap-4">
                            <button onClick={handleExport} className="px-6 py-3 bg-blue-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-700 transition-all">Export JSON</button>
                            <button onClick={() => fileInputRef.current?.click()} className="px-6 py-3 bg-white border border-blue-200 text-blue-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-50 transition-all">Import File</button>
                            <input type="file" ref={fileInputRef} onChange={handleImport} accept=".json" className="hidden" />
                          </div>
                       </div>
                       <div className="p-8 bg-slate-50 rounded-3xl border border-slate-200">
                          <h3 className="font-black text-slate-500 uppercase text-xs tracking-widest mb-4">Local Database Engine</h3>
                          <p className="text-sm text-slate-400 font-medium mb-2 uppercase tracking-tighter">Schema Version: {db.get().version}</p>
                          <p className="text-sm text-slate-400 font-medium uppercase tracking-tighter">Last Sync: {new Date(db.get().lastSync).toLocaleTimeString()}</p>
                          <button onClick={() => db.reset()} className="mt-8 text-red-400 text-[10px] font-black uppercase tracking-widest hover:text-red-600">Factory Reset Database</button>
                       </div>
                    </div>
                  </div>
                </div>
              );
            default: return <DashboardScreen />;
          }
        })()}
      </div>
    );
  };

  return (
    <Layout 
      activeTab={currentScreen.toLowerCase()} 
      setActiveTab={(tab) => setCurrentScreen(tab.toUpperCase() as Screen)} 
      // Fix: Use displayName property from User interface in types.ts instead of non-existent name property.
      currentUser={{ name: currentUser?.displayName, role: currentUser?.role }}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
