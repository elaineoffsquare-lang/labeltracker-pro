import { database } from '../LabelTrackerDatabase';
import { ShipmentEntity, ShipmentStatus, ShipmentType } from '../entity/ShipmentEntity';
import { ProductRepository } from '../product/ProductRepository';

export class ShipmentRepository {
  private productRepo = new ProductRepository();

  getAll(): ShipmentEntity[] {
    return database.get().shipments;
  }

  insert(shipment: ShipmentEntity) {
    const db = database.get();
    db.shipments.unshift(shipment);
    database.save(db);
  }

  /**
   * Updates shipment status and triggers side effects:
   * 1. If Inbound & Delivered: Increases product stock.
   * 2. If Inbound & Delivered: Updates Product record with the source invoice info.
   */
  updateStatus(id: string, status: ShipmentStatus) {
    const db = database.get();
    const shipment = db.shipments.find(s => s.id === id);
    if (shipment) {
      const oldStatus = shipment.status;
      shipment.status = status;
      database.save(db);

      // Business Rule: Inbound shipment delivered increases stock & updates product invoice
      if (shipment.shipmentType === ShipmentType.INBOUND && 
          oldStatus !== ShipmentStatus.DELIVERED && 
          status === ShipmentStatus.DELIVERED && 
          shipment.productId && shipment.quantity) {
        
        // 1. Update the current physical stock level
        this.productRepo.updateStock(shipment.productId, shipment.quantity);
        
        // 2. Update the product master category with the source of this restock
        if (shipment.invoiceNumber) {
          this.productRepo.updateInvoice(
            shipment.productId, 
            shipment.invoiceNumber, 
            shipment.invoiceDateMillis || Date.now()
          );
        }
      }
    }
  }
}
