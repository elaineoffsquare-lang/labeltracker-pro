
export enum PaymentStatus {
  PAID = 'PAID',
  CREDIT = 'CREDIT'
}

export interface OrderEntity {
  id: string;
  productId: string;
  productName: string; // Snapshot for history
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  orderDate: number;
  customerName?: string;
  notes?: string;
  invoiceNumber?: string;
  invoiceDateMillis?: number;
  paymentStatus: PaymentStatus;
}
