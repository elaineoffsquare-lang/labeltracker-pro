
export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export interface UserEntity {
  id: string;
  name: string;
  role: UserRole;
}
