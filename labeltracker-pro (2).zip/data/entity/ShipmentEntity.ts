
export enum ShipmentType {
  INBOUND = 'INBOUND',
  OUTBOUND = 'OUTBOUND'
}

export enum ShipmentStatus {
  PENDING = 'PENDING',
  IN_TRANSIT = 'IN_TRANSIT',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED'
}

export interface ShipmentEntity {
  id: string;
  shipmentType: ShipmentType;
  trackingNumber: string;
  carrier: string;
  origin: string;
  destination: string;
  shipmentDateMillis: number;
  etaMillis?: number;
  status: ShipmentStatus;
  notes?: string;
  productId?: string;
  quantity?: number;
  // Invoice tracking fields
  invoiceNumber?: string;
  invoiceDateMillis?: number;
}
