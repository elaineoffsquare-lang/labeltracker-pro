export interface ProductEntity {
  id: string;
  productName: string;
  labelName: string; // SKU
  unitPrice: number;
  stockQuantity: number;
  minStockAlertLevel: number;
  size?: string;
  pcsPerRoll?: number;
  imageUri?: string;
  lastInvoiceNumber?: string;
  lastInvoiceDate?: number; // Timestamp of the last restock/purchase invoice
}