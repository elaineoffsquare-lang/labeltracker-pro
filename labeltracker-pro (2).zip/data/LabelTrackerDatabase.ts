
import { ProductEntity } from './entity/ProductEntity';
import { OrderEntity } from './entity/OrderEntity';
import { ShipmentEntity, ShipmentType, ShipmentStatus } from './entity/ShipmentEntity';
import { UserEntity, UserRole } from './entity/UserEntity';

const STORAGE_KEY = 'label_tracker_v2_db';

interface DatabaseSchema {
  products: ProductEntity[];
  orders: OrderEntity[];
  shipments: ShipmentEntity[];
  users: UserEntity[];
}

const INITIAL_DATA: DatabaseSchema = {
  products: [
    { id: '1', productName: 'Matte Vinyl', labelName: 'SKU-001', unitPrice: 20, stockQuantity: 100, minStockAlertLevel: 10, size: '10cm x 15cm', pcsPerRoll: 500 },
    { id: '2', productName: 'Glossy Finish', labelName: 'SKU-002', unitPrice: 25, stockQuantity: 5, minStockAlertLevel: 10, size: 'A4', pcsPerRoll: 100 }
  ],
  orders: [],
  shipments: [
    { id: 's1', shipmentType: ShipmentType.INBOUND, trackingNumber: 'TRK123', carrier: 'China Logistics', origin: 'Guangzhou', destination: 'Kuala Lumpur', shipmentDateMillis: Date.now(), status: ShipmentStatus.IN_TRANSIT, productId: '1', quantity: 50 }
  ],
  users: [
    { id: 'u1', name: 'Admin User', role: UserRole.ADMIN },
    { id: 'u2', name: 'Staff Member', role: UserRole.USER }
  ]
};

export class LabelTrackerDatabase {
  private static instance: LabelTrackerDatabase;
  
  private constructor() {
    if (!localStorage.getItem(STORAGE_KEY)) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_DATA));
    }
  }

  static getInstance(): LabelTrackerDatabase {
    if (!this.instance) this.instance = new LabelTrackerDatabase();
    return this.instance;
  }

  get(): DatabaseSchema {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || JSON.stringify(INITIAL_DATA));
  }

  save(data: DatabaseSchema) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    window.dispatchEvent(new Event('db_updated'));
  }
}

export const database = LabelTrackerDatabase.getInstance();
