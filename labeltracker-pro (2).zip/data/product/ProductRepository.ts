import { database } from '../LabelTrackerDatabase';
import { ProductEntity } from '../entity/ProductEntity';

export class ProductRepository {
  getAll(): ProductEntity[] {
    return database.get().products;
  }

  getById(id: string): ProductEntity | undefined {
    return this.getAll().find(p => p.id === id);
  }

  insert(product: ProductEntity) {
    const db = database.get();
    db.products.push(product);
    database.save(db);
  }

  update(product: ProductEntity) {
    const db = database.get();
    const index = db.products.findIndex(p => p.id === product.id);
    if (index !== -1) {
      db.products[index] = product;
      database.save(db);
    }
  }

  delete(id: string) {
    const db = database.get();
    db.products = db.products.filter(p => p.id !== id);
    database.save(db);
  }

  updateStock(id: string, delta: number) {
    const db = database.get();
    const product = db.products.find(p => p.id === id);
    if (product) {
      product.stockQuantity += delta;
      database.save(db);
    }
  }

  /**
   * Updates the master product record with the latest purchase details.
   */
  updateInvoice(id: string, invoiceNumber: string, invoiceDate: number) {
    const db = database.get();
    const product = db.products.find(p => p.id === id);
    if (product) {
      product.lastInvoiceNumber = invoiceNumber;
      product.lastInvoiceDate = invoiceDate;
      database.save(db);
    }
  }
}
