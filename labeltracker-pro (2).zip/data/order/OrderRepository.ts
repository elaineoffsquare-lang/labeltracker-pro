
import { database } from '../LabelTrackerDatabase';
import { OrderEntity } from '../entity/OrderEntity';
import { ProductRepository } from '../product/ProductRepository';

export class OrderRepository {
  private productRepo = new ProductRepository();

  getAll(): OrderEntity[] {
    return database.get().orders;
  }

  insert(order: OrderEntity) {
    const db = database.get();
    db.orders.unshift(order);
    database.save(db);
    // Business Rule: Decrease stock
    this.productRepo.updateStock(order.productId, -order.quantity);
  }

  delete(id: string) {
    const db = database.get();
    const order = db.orders.find(o => o.id === id);
    if (order) {
      db.orders = db.orders.filter(o => o.id !== id);
      database.save(db);
      // Business Rule: Restore stock
      this.productRepo.updateStock(order.productId, order.quantity);
    }
  }
}
